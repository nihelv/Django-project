# Django-model, server admin page control

## 1. 주어진 정보에 따라 models.py 작성
![Alt text](%ED%99%94%EB%A9%B4%20%EC%BA%A1%EC%B2%98%202023-03-24%20173251.png)

## 2. 관리자 페이지 모델 등록
![Alt text](%ED%99%94%EB%A9%B4%20%EC%BA%A1%EC%B2%98%202023-03-24%20165603.png)

## 3. 데이터 생성, 조회, 수정, 삭제
![Alt text](%ED%99%94%EB%A9%B4%20%EC%BA%A1%EC%B2%98%202023-03-24%20170520.png)<br>
![Alt text](%ED%99%94%EB%A9%B4%20%EC%BA%A1%EC%B2%98%202023-03-24%20170652.png)<br>
![Alt text](%ED%99%94%EB%A9%B4%20%EC%BA%A1%EC%B2%98%202023-03-24%20170756.png)<br>

## model에 category 필드 추가
![Alt text](%ED%99%94%EB%A9%B4%20%EC%BA%A1%EC%B2%98%202023-03-24%20173845.png)<br>
![](%ED%99%94%EB%A9%B4%20%EC%BA%A1%EC%B2%98%202023-03-24%20173056.png)<br>
![Alt text](%ED%99%94%EB%A9%B4%20%EC%BA%A1%EC%B2%98%202023-03-24%20174058.png)